//
// Copyright (C) 2015 crosire & contributors
// License: https://github.com/crosire/scripthookvdotnet#license
//

namespace RDR2
{
	public enum eEntityType
	{
		None = 0,
		Ped = 1,
		Vehicle = 2,
		Object = 3,
		Prop = 3,
	}
}
