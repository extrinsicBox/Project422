﻿namespace RDR2
{
	public enum eFleeStyle
	{
		NervousRetreat = 0,
		AnnoyedRetreat = 1,
		PotentialThreat = 2,
		MajorThreat = 3,
		ClearTheArea = 4,
		MortallyInjured = 5,
		CalmRetreat = 6,
		InjuredRider = 7,
		IntimidatedRetreat = 8,
		HorseTamingQuick = 9,
		HorseTamingSlow = 10,
		StolenVehicleRetreat = 11,
		CautiousRetreat = 12,
	};
}
