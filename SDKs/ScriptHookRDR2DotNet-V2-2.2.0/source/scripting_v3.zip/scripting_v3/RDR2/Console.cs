﻿using System;

/*namespace RDR2.Console
{
	public static class Console
	{
		static RDR2DN.Console _console;

		public static void PrintError(string message)
		{
			_console = RDR2DN.ScriptDomain.CurrentDomain.AppDomain.GetData("Console") as RDR2DN.Console;
			_console.PrintError(string.Empty, message);
		}
		public static void PrintInfo(string message)
		{
			_console = RDR2DN.ScriptDomain.CurrentDomain.AppDomain.GetData("Console") as RDR2DN.Console;
			_console.PrintInfo(string.Empty, message);

		}
		public static void PrintWarning(string message)
		{
			_console = RDR2DN.ScriptDomain.CurrentDomain.AppDomain.GetData("Console") as RDR2DN.Console;
			_console.PrintWarning(string.Empty, message);
		}
	}
}*/
