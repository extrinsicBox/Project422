﻿//
// Copyright (C) 2015 crosire & contributors
// License: https://github.com/crosire/scripthookvdotnet#license
//

namespace RDR2
{
	public enum GameVersion
	{
		Unknown = -1,
		v1_0_1207_60,
		v1_0_1207_69,
		v1_0_1207_73,
		v1_0_1207_77,
		v1_0_1207_80,
		v1_0_1232_13,
		v1_0_1232_17,
		v1_0_1311_12,
		v1_0_1436_25,
		v1_0_1436_31,
		v1_0_1491_16,
	}
}
