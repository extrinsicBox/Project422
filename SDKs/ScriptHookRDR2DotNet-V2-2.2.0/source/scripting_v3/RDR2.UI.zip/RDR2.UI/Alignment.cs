//
// Copyright (C) 2015 crosire & contributors
// License: https://github.com/crosire/scripthookvdotnet#license
//

namespace RDR2.UI
{
	public enum Alignment
	{
		Center = 0,
		Left = 1,
		Right = 2,
	}
}
